// Orvex Chrome: зв'язок з Orvex на цьому ж ноутбуці (127.0.0.1). Назовні нічого не передається.
const BASE = "http://127.0.0.1:8765";
const sleep = ms => new Promise(r => setTimeout(r, ms));
const low = s => (s || "").toLowerCase();
let running = false;

function match(tabs, q) {
  q = low(q).trim();
  if (!q) return null;
  const exact = tabs.find(t => low(t.title) === q || low(t.url) === q);
  if (exact) return exact;
  const hits = tabs.filter(t => low(t.title).includes(q) || low(t.url).includes(q));
  return hits.find(t => t.active) || hits[0] || null;
}

async function findGroup(name) {
  const n = low(name).trim();
  const gs = await chrome.tabGroups.query({});
  return gs.find(g => low(g.title) === n) || gs.find(g => n && low(g.title).includes(n)) || null;
}

async function focusTab(t) {
  await chrome.tabs.update(t.id, { active: true });
  await chrome.windows.update(t.windowId, { focused: true });
}

async function addToGroup(tabId, name) {
  const g = await findGroup(name);
  if (g) {
    await chrome.tabs.group({ tabIds: [tabId], groupId: g.id });
  } else {
    const gid = await chrome.tabs.group({ tabIds: [tabId] });
    await chrome.tabGroups.update(gid, { title: name });
  }
}

const OPS = {
  async state() {
    const [tabs, groups] = await Promise.all([chrome.tabs.query({}), chrome.tabGroups.query({})]);
    const gname = new Map(groups.map(g => [g.id, g.title || "(без назви)"]));
    return {
      tabs: tabs.map(t => ({ title: t.title, url: t.url, active: t.active,
                             group: t.groupId > 0 ? gname.get(t.groupId) : "" })),
      groups: groups.map(g => ({ title: g.title, color: g.color, collapsed: g.collapsed })),
    };
  },
  async activate({ query }) {
    const t = match(await chrome.tabs.query({}), query);
    if (!t) throw new Error("вкладку «" + query + "» не знайдено");
    await focusTab(t);
    return { title: t.title };
  },
  async new_tab({ url, group }) {
    const t = await chrome.tabs.create({ url: url || "chrome://newtab", active: true });
    if (group) await addToGroup(t.id, group);
    await chrome.windows.update(t.windowId, { focused: true });
    return {};
  },
  async open_group({ name }) {
    const g = await findGroup(name);
    if (!g) throw new Error("групу «" + name + "» не знайдено");
    await chrome.tabGroups.update(g.id, { collapsed: false });
    const tabs = await chrome.tabs.query({ groupId: g.id });
    if (tabs.length) await focusTab(tabs[0]);
    return { tabs: tabs.length };
  },
  async add_to_group({ query, group }) {
    if (!group) throw new Error("не вказано назву групи");
    let t;
    if (query) {
      t = match(await chrome.tabs.query({}), query);
      if (!t) throw new Error("вкладку «" + query + "» не знайдено");
    } else {
      t = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      if (!t) throw new Error("немає активної вкладки");
    }
    await addToGroup(t.id, group);
    return { title: t.title };
  },
};

async function handle(cmd) {
  const f = OPS[cmd.op];
  if (!f) throw new Error("невідома дія " + cmd.op);
  return await f(cmd.args || {});
}

async function loop() {
  if (running) return;
  running = true;
  while (true) {
    try {
      const r = await fetch(BASE + "/ext/poll", { cache: "no-store", headers: { "X-Orvex-Ext": "1" } });
      if (r.status === 200) {
        const cmd = await r.json();
        let out;
        try { out = { ok: true, data: await handle(cmd) }; }
        catch (e) { out = { ok: false, error: String((e && e.message) || e) }; }
        await fetch(BASE + "/ext/result", {
          method: "POST", headers: { "content-type": "application/json", "X-Orvex-Ext": "1" },
          body: JSON.stringify({ id: cmd.id, ...out }),
        });
      } else if (r.status !== 204) {
        await sleep(3000);
      }
    } catch (e) {
      await sleep(3000);          // Orvex не запущено: пробуємо знову
    }
  }
}

chrome.alarms.create("orvex-keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => loop());
chrome.runtime.onStartup.addListener(() => loop());
chrome.runtime.onInstalled.addListener(() => loop());
setInterval(() => chrome.runtime.getPlatformInfo(), 20000);   // тримає службовий процес активним
loop();
